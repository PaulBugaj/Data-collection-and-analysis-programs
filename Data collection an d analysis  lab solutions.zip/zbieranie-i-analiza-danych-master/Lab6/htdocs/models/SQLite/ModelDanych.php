<?php
// SQLite

class ModelDanych{

public $filename = 'models/SQLite/data/ttsi_db.sqlite3';
public $db;

public function __construct(){

    if ($db = new SQLite3($this->filename)) {
        $q = @$db->query('SELECT requests FROM wpis WHERE id = 1');
        if ($q === false) {
			$db->query('CREATE TABLE wpis (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, requests int, podstrona text, tresc text); 
                        INSERT INTO wpis (id, podstrona, tresc) VALUES (1, "...", "...");');
            $hits = 1;
        } else {
            $result = $q->fetchArray()[0];
            $hits = $result+1;
        }
        $db->query("UPDATE wpis SET requests = '$hits' WHERE id = 1");
    } else {
        die($err);
    }

	$this->db = $db;
	
}


public function pobierz($page){

    if ($page=="admin"){
        $edit = isset($_GET["edit"]) && $_GET["edit"] != "" ? $_GET["edit"] : 'glowna';
        $query = "SELECT tresc FROM wpis WHERE podstrona=\"".$edit."\" LIMIT 1";    }
    else
        $query = "SELECT tresc FROM wpis WHERE podstrona=\"".$page."\" LIMIT 1";

	$queryid = $this->db->query($query);
    $error_code = $this->db->lastErrorCode();
    if($error_code == 0){
        $row = $queryid->fetchArray()[0];
        $tresc = stripslashes($row);
        }
    else{
        $tresc = "Błąd odczytu z bazy danych: ".$error_code;
    }

	return $tresc;

}



public function zapisz($tresc, $edit){

	// Zapisanie nowej tresci
	$tresc = trim(strip_tags(addslashes($tresc)));
    
    $query = "INSERT OR REPLACE INTO wpis (podstrona, tresc) VALUES (\"".$edit."\", \"".$tresc."\");";

	$queryid = $this->db->query($query);
    $error_code = $this->db->lastErrorCode();
	if (!$queryid) die('Błąd zapisu do bazy danych: ' . $error_code);
	Admin::$info = 'Zapisano.';

}

}
?>