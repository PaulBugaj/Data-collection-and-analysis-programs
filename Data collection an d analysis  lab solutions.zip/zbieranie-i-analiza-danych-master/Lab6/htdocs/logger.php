<?php
    $pageX = $_GET["pageX"];
    $pageY = $_GET["pageY"];
    $time = time();
    $page = isset($_GET['page']) ? $_GET['page'] : 'glowna';

    $logData = "[" . date('Y-m-d-h-m-s') . "]\r\n" . "Strona: " . $page . ", Koordynaty kursora: X: " . $pageX . ", Y:" . $pageY . "\r\nHost: " . getallheaders()['Host'] . "\r\nUser-Agent: " . getallheaders()['User-Agent'] . "\r\nAccept-Language: " . getallheaders()['Accept-Language'] . "\r\n\r\n";

    $file = fopen("logi.txt", "a");
    fputs($file, $logData);
    fclose($file);
/*
    echo '<div>
            <br>' . date('Y-m-d-h-m-s') . '</br>
            <br>' . "Strona: " . $page . ", X: " . $pageX . ", Y:" . $pageY . '</br>
            <br>Host: ' . getallheaders()['Host'] . '</br>
            <br>User-Agent: ' . getallheaders()['User-Agent'] . '</br>
            <br>Accept-Language: ' . getallheaders()['Accept-Language'] . '</br>
          </div>';*/
?>