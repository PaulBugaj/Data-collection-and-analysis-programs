numberOfPoints <- 500
prob <- 0.1
#Generating circles by creating random points within the circle
#blue circle
r <- sqrt(runif(numberOfPoints))
t <- 2*pi*runif(numberOfPoints)
x <- -5 + r*cos(t) 
y <- r*sin(t)

x2 <- x
corrupt <- rbinom(length(x), 1, prob)    # choose an average of 10% to corrupt at random
corrupt <- as.logical(corrupt)
noise <- rnorm(sum(corrupt), -3, 0.5) # generate the noise to add
noise <- noise + rnorm(sum(corrupt), 3, 0.5)
x2[corrupt] <- x2[corrupt] + noise      # about 10% of x has been corrupted
y2 <- y
corrupt <- rbinom(length(y), 1, prob)    # choose an average of 10% to corrupt at random (vector, size, probability)
corrupt <- as.logical(corrupt)
noise <- rnorm(sum(corrupt), -3, 0.5) # generate the noise to add (number of values, mean, variance)
noise <- noise + rnorm(sum(corrupt), 3, 0.5)
y2[corrupt] <- y2[corrupt] + noise      # about 10% of y has been corrupted

#plot(x2, y2, pch="*", col="blue", xlim=c(-10,10), ylim=c(-10,10))



# red circle
r <- sqrt(runif(numberOfPoints))
t <- 2*pi*runif(numberOfPoints)
x <- 5 + r*cos(t)
y <- r*sin(t)

x3 <- x
corrupt <- rbinom(length(x), 1, prob)    # choose an average of 10% to corrupt at random
corrupt <- as.logical(corrupt)
noise <- rnorm(sum(corrupt), -3, 0.5) # generate the noise to add
noise <- noise + rnorm(sum(corrupt), 3, 0.5)
x3[corrupt] <- x3[corrupt] + noise      # about 10% of x has been corrupted
y3 <- y
corrupt <- rbinom(length(y), 1, prob)    # choose an average of 10% to corrupt at random (vector, size, probability)
corrupt <- as.logical(corrupt)
noise <- rnorm(sum(corrupt), -3, 0.5) # generate the noise to add (number of values, mean, variance)
noise <- noise + rnorm(sum(corrupt), 3, 0.5)
y3[corrupt] <- y3[corrupt] + noise      # about 10% of y has been corrupted

#plot(x3, y3, pch="*", col="blue", xlim=c(-10,10), ylim=c(-10,10))




final_x <- rbind(x2,x3)
final_y <- rbind(y2,y3)
plot(final_x, final_y, pch=".", col="blue", xlim=c(-10,10), ylim=c(-10,10))




hc <- hclust(dist(x3[corrupt]), "single")
plot(hc, labels = NULL, hang = 0.1, check = TRUE,
     axes = TRUE, frame.plot = FALSE, ann = TRUE,
     main = "Cluster Dendrogram, Single method",
     sub = NULL, xlab = NULL, ylab = "Height")


hc <- hclust(dist(x3[corrupt]), "complete")
plot(hc, labels = NULL, hang = 0.1, check = TRUE,
     axes = TRUE, frame.plot = FALSE, ann = TRUE,
     main = "Cluster Dendrogram, Complete method",
     sub = NULL, xlab = NULL, ylab = "Height")


hc <- hclust(dist(x3[corrupt]), "average")
plot(hc, labels = NULL, hang = 0.1, check = TRUE,
     axes = TRUE, frame.plot = FALSE, ann = TRUE,
     main = "Cluster Dendrogram, Average method",
     sub = NULL, xlab = NULL, ylab = "Height")


hc <- hclust(dist(x3[corrupt]), "ward.D")
plot(hc, labels = NULL, hang = 0.1, check = TRUE,
     axes = TRUE, frame.plot = FALSE, ann = TRUE,
     main = "Cluster Dendrogram, ward.D method",
     sub = NULL, xlab = NULL, ylab = "Height")


hc <- hclust(dist(x3[corrupt]), "ward.D2")
plot(hc, labels = NULL, hang = 0.1, check = TRUE,
     axes = TRUE, frame.plot = FALSE, ann = TRUE,
     main = "Cluster Dendrogram, ward.D2 method",
     sub = NULL, xlab = NULL, ylab = "Height")
